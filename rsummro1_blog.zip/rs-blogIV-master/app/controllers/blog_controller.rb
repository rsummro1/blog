class BlogController < ApplicationController
end
