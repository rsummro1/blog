module Blog
   class PagesController < BlogController
    
        def about
        end

        def contact
        end 
    end  
end